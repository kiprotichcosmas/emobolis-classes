number1 = 5
number2 = 20
number3 = 95.786

print(number1 + number2)  # addition
print(number2 - number1)  # subtraction
print(number2 * number3)  # multiplication
print(number3 / number2)  # division
print(number2 ** number1)  # powering the number using "**"
print(number3 % number1)
