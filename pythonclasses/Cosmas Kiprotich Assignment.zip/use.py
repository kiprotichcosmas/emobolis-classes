# import my_functions
#
# my_functions.multiply(2, 69,69)
# my_functions.add(20,67)

from my_functions import add, multiply

from my_functions import multiply as cosmas

add(10, 50)
multiply(3, 5, 8)

cosmas(8, 8, 9)
