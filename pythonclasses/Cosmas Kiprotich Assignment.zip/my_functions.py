def add(a, b):
    print(a + b)


def multiply(a, b, c):
    print(a * b * c)
