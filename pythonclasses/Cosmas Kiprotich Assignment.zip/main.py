print(979898)
x = 15
y = 17
pi = 22 / 7
radius = 13.5

name = "cosmas"
sentence = "I love working hard for this coding class "
city = "Harare"
distance_to_nairobi = 900
person_no_2 = "Kiptoyot"
min_age_per_person = 49
is_over_age = False
is_child = True

print(x, y, pi, radius, name, sentence, city, distance_to_nairobi, person_no_2, min_age_per_person, is_over_age,
      is_child)
